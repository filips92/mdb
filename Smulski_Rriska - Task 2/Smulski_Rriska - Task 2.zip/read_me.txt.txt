NOTE:
This is an extension of the Task1 (it will not work without executing the scripts from the previous exercise).