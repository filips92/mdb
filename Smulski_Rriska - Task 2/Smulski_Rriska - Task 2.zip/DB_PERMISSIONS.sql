CREATE DIRECTORY MEDIA_FILES AS '/media/sf_vmshared/img/';
grant read, write on directory MEDIA_FILES to hr;
commit;
